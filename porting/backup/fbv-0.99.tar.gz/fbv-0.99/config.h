#define IDSTRING "fbv 0.99, s-tech"
#define DEFAULT_FRAMEBUFFER "/dev/fb0"
#define FBV_SUPPORT_GIF
#define FBV_SUPPORT_JPEG
#define FBV_SUPPORT_PNG
#define FBV_SUPPORT_BMP
