#ifndef NPY_IMPORT_H
#define NPY_IMPORT_H

#include <Python.h>

/*! \brief Fetch and cache Python function.
 *
 * Import a Python function and cache it for use. The function checks if
 * cache is NULL, and if not NULL imports the Python function specified by
 * \a module and \a function, increments its reference count, and stores
 * the result in \a cache. Usually \a cache will be a static variable and
 * should be initialized to NULL. On error \a cache will contain NULL on
 * exit,
 *
 * @param module Absolute module name.
 * @param attr module attribute to cache.
 * @param cache Storage location for imported function.
 */
NPY_INLINE static void
npy_cache_import(const char *module, const char *attr, PyObject **cache)
{
    if (*cache == NULL) {
        PyObject *mod = PyImport_ImportModule(module);

        if (mod != NULL) {
            *cache = PyObject_GetAttrString(mod, attr);
            Py_DECREF(mod);
        }
    }
}

NPY_INLINE static PyObject *
npy_import(const char *module, const char *attr)
{
    PyObject *mod = PyImport_ImportModule(module);
    PyObject *ret = NULL;

    if (mod != NULL) {
        ret = PyObject_GetAttrString(mod, attr);
    }
    Py_XDECREF(mod);

    return ret;
}

#endif
