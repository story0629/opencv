GUI for Interactive Visual Debugging of Computer Vision Programs
================================================================
